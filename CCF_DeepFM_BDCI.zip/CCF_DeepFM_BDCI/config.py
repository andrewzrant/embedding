
TRAIN_FILE = "C:\/Users\/ASUS\/Desktop\/DeepFM_BDCI\/train_feature.csv"
TEST_FILE = "C:\/Users\/ASUS\/Desktop\/DeepFM_BDCI\/test_feature.csv"

SUB_DIR = "E:/CCF/output"


NUM_SPLITS = 5
RANDOM_SEED = 42

# types of columns of the dataset dataframe
CATEGORICAL_COLS = [
          "service_type",
          "is_mix_service",
          "many_over_bill",
          "contract_type",
          "is_promise_low_consume"
          "net_service",
          "gender",
          "complaint_level",
          "online_time_map",       
          "is_complaint",
		  'online_morethan_contract',
		  'local_morethan_service1',
		  'local_morethan_service2',
		  'service1_morethan_service2',
		  'traffic1'
       
]

NUMERIC_COLS = [
    # binary

    # numeric
     "age",
     "online_time",
     "1_total_fee",
     "2_total_fee",
     "3_total_fee",
     "4_total_fee",
     "month_traffic",
     "contract_time",
     "pay_times",
     "pay_num",
     "last_month_traffic",
     "local_trafffic_month",
     "local_caller_time",
     "service1_caller_time",
     "service2_caller_time",
     "former_complaint_num",
     "former_complaint_fee",
     "2_no_compliant_fee_del_min",
     "3_no_compliant_fee_del_min",
     "4_no_compliant_fee_del_min",
     "service1_caller_time_max",
     "service2_caller_time_max",
     "pay_fee_former_count",
     "num_fee_former_count",
     "level_fee_former_count",
     "online_time_fee_former_count",
     "age_fee_former_count",
     "1_total_fee_former_count",
     "2_total_fee_former_count",
     "3_total_fee_former_count",
     '4_total_fee_former_count', 
     'fee_min',
     'last_month_traffic_rest',
     'last_month_traffic_fee_former_count',
     'pay_num_pertime', 
     'rate_diff_1_fee_up',
     'rate_diff_2_fee_up',
     'rate_diff_3_fee_up',
     'rate_diff_4_fee_up',
     'rate_diff_1_fee_down',
     'rate_diff_2_fee_down', 
     'rate_diff_3_fee_down',
     'rate_diff_4_fee_down',
     'month_traffic_fee', 
     'rate_diff_local_traffic_up',
     'rate_diff_local_traffic_down',
     'rate_diff_month_traffic_up',
     'rate_diff_month_traffic_down',
     'rate_diff_lastmonth_traffic_up',
	 '21_total',
	 '32_total',
	 '43_total',
	 'out1_fee1',
	 'out1_fee2',
	 'out1_fee3',
	 'out1_fee4',
	 'out1_fee1_rate',
	 'out1_fee2_rate',
	 'out1_fee3_rate',
	 'out1_fee4_rate',
	 'out2_fee1',
	 'out2_fee2',
	 'out2_fee3',
	 'out2_fee4',
	 'out2_fee1_rate',
	 'out2_fee2_rate',
	 'out2_fee3_rate',
	 'out2_fee4_rate',
     ""
    
    # feature engineering
]

IGNORE_COLS = [
]